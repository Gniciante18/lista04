# Lista 04 - Arrays (Java)

Exercícios 01 a 10 sobre arrays: declaração, percurso, acumuladores,
busca e cópia. Entrada com `Scanner`, saída com `System.out`.

- Código-fonte em `src/`
- Roda em qualquer versão recente do Java (JDK 17+)
